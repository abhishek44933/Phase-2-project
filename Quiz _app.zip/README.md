# Simple-Angular-Quiz-App
A simple quiz app as an Angular practice (refresher) project
